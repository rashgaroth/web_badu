<nav class="navbar navbar-light bg-light">
<a class="navbar-brand" href="#"><?php echo e($name); ?></a>
</nav><?php /**PATH C:\Users\Rashtaurigae\Desktop\Badu\Web\resources\views/content/component/navbar.blade.php ENDPATH**/ ?>
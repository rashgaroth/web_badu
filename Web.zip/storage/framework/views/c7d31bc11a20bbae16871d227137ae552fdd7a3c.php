<?php $__env->startSection('title', 'Home'); ?>
<?php $__env->startSection('content'); ?>


<?php
$volly = 'https://4.bp.blogspot.com/-u_IPP1Ftt5Q/WMf6Zi95FHI/AAAAAAAAAFI/PeKMXyqOUrkix1z2QWZZdMPFW2e2JTA9wCLcB/s1600/2016-08-21-Volleyball-Men-thumbnail.jpg';
$basket = 'https://eyofbaku2019.com/images/sport%20pages/basketball.jpg';
$futsal = 'https://d10dnch8g6iuzs.cloudfront.net/picture/96420200220173453419/width/480/height/306';
$badminton = 'https://gtimg.tokyo2020.org/image/private/t_article-image-desktop/production/byaigvjg4eju6mxwmiyn';    

$pic_roy = asset('/images/voulenteer/roy.jpg');
$pic_kemal = asset('/images/voulenteer/kemal.png');
$pic_dwiyan = asset('/images/voulenteer/dwiyan.png');
$pic_sasa = asset('/images/voulenteer/sasa.png');
?>
<!-- Start slider area -->
<?php $__env->startComponent('content.component.jumbotron_banner'); ?>
    <?php $__env->slot('jb_product'); ?>
        BADu
    <?php $__env->endSlot(); ?>
    <?php $__env->slot('jb_content'); ?>
        BADu adalah startup digital yang memberikan layanan kepada user berupa booking 
        beberapa lapangan dengan mudah, aman, dan terpercaya!
    <?php $__env->endSlot(); ?>
<?php if (isset($__componentOriginalb2f3313bcd15c29ccd9179e6f8225cc3e5a02761)): ?>
<?php $component = $__componentOriginalb2f3313bcd15c29ccd9179e6f8225cc3e5a02761; ?>
<?php unset($__componentOriginalb2f3313bcd15c29ccd9179e6f8225cc3e5a02761); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<!-- End slider area -->
<!-- Start help us area -->
<?php $__env->startComponent('content.component.provider', ['lapangan' => 3]); ?>

<?php $__env->slot('logo_0'); ?>
    fa fa-futbol-o
<?php $__env->endSlot(); ?>
<?php $__env->slot('lapangan_0'); ?>
        Lapangan Futsal
<?php $__env->endSlot(); ?>
<?php $__env->slot('deskripsi_0'); ?>
        Pada layanan kami, kami memiliki fitur pada user untuk dapat membooking lapangan Basket
<?php $__env->endSlot(); ?>
<?php $__env->slot('button_0'); ?>
    Lihat Daftar Lapangan
<?php $__env->endSlot(); ?>

<?php $__env->slot('logo_1'); ?>
    fa fa-futbol-o
<?php $__env->endSlot(); ?>
<?php $__env->slot('lapangan_1'); ?>
        Lapangan Basket
<?php $__env->endSlot(); ?>
<?php $__env->slot('deskripsi_1'); ?>
        Pada layanan kami, kami memiliki fitur pada user untuk dapat membooking lapangan Basket
<?php $__env->endSlot(); ?>
<?php $__env->slot('button_1'); ?>
    Lihat Daftar Lapangan
<?php $__env->endSlot(); ?>

<?php $__env->slot('logo_2'); ?>
    fa fa-futbol-o
<?php $__env->endSlot(); ?>
<?php $__env->slot('lapangan_2'); ?>
        Lapangan Volly
<?php $__env->endSlot(); ?>
<?php $__env->slot('deskripsi_2'); ?>
        Pada layanan kami, kami memiliki fitur pada user untuk dapat membooking lapangan Volly
<?php $__env->endSlot(); ?>
<?php $__env->slot('button_2'); ?>
    Lihat Daftar Lapangan
<?php $__env->endSlot(); ?>

<?php if (isset($__componentOriginalfb2b479c81ae2fd45857612f84a5e1bee3aada9a)): ?>
<?php $component = $__componentOriginalfb2b479c81ae2fd45857612f84a5e1bee3aada9a; ?>
<?php unset($__componentOriginalfb2b479c81ae2fd45857612f84a5e1bee3aada9a); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<!-- End help us area -->
<!-- Start our gallery -->
<?php $__env->startComponent('content.component.gallery', ['gallery' => [$volly,$basket,$futsal,$badminton]]); ?>
    
<?php if (isset($__componentOriginal8b3de0847b34c2bca3706569c2140a63ec43d7c3)): ?>
<?php $component = $__componentOriginal8b3de0847b34c2bca3706569c2140a63ec43d7c3; ?>
<?php unset($__componentOriginal8b3de0847b34c2bca3706569c2140a63ec43d7c3); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<!-- End our gallery -->
<!-- Start countdown area -->

<!-- End countdown area -->
<!-- Start our volunteers area -->
<?php $__env->startComponent('content.component.voulenteer', ['person' => 4]); ?>
    <?php $__env->slot('foto_0'); ?>
    <?php echo e($pic_roy); ?>

    <?php $__env->endSlot(); ?>
    <?php $__env->slot('name_0'); ?>
    Roy Antares
    <?php $__env->endSlot(); ?>
    <?php $__env->slot('as_0'); ?>
     Chief Executive Officer
    <?php $__env->endSlot(); ?>

    <?php $__env->slot('foto_1'); ?>
    <?php echo e($pic_kemal); ?>

    <?php $__env->endSlot(); ?>
    <?php $__env->slot('name_1'); ?>
    Kemal Attar
    <?php $__env->endSlot(); ?>
    <?php $__env->slot('as_1'); ?>
    Product Development
    <?php $__env->endSlot(); ?>

    <?php $__env->slot('foto_2'); ?>
    <?php echo e($pic_dwiyan); ?>

    <?php $__env->endSlot(); ?>
    <?php $__env->slot('name_2'); ?>
    Dwiyan Putra
    <?php $__env->endSlot(); ?>
    <?php $__env->slot('as_2'); ?>
    Software Developer
    <?php $__env->endSlot(); ?>

    <?php $__env->slot('foto_3'); ?>
    <?php echo e($pic_sasa); ?>

    <?php $__env->endSlot(); ?>
    <?php $__env->slot('name_3'); ?>
    Anisa Rahmatanti
    <?php $__env->endSlot(); ?>
    <?php $__env->slot('as_3'); ?>
    Chief Financial Officer
    <?php $__env->endSlot(); ?>
<?php if (isset($__componentOriginaleb55da2438c32d688e8b109ff6fa081e176e402d)): ?>
<?php $component = $__componentOriginaleb55da2438c32d688e8b109ff6fa081e176e402d; ?>
<?php unset($__componentOriginaleb55da2438c32d688e8b109ff6fa081e176e402d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<!-- End our volunteers area -->
<!-- Start people says area -->
<?php $__env->startComponent('content.component.comment'); ?>
    
<?php if (isset($__componentOriginal27eb41f94401dc63a8a14be956dabae6d158f1ce)): ?>
<?php $component = $__componentOriginal27eb41f94401dc63a8a14be956dabae6d158f1ce; ?>
<?php unset($__componentOriginal27eb41f94401dc63a8a14be956dabae6d158f1ce); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('content.common.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Rashtaurigae\Desktop\Badu\Web\resources\views/content/content.blade.php ENDPATH**/ ?>
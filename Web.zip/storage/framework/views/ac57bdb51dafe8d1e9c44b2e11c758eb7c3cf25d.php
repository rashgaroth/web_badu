<?php $__env->startSection('title','Daftar'); ?>
<?php $__env->startSection('daftar'); ?>
    <?php $__env->startComponent('daftar.component.welcome_banner'); ?>
        <?php $__env->slot('jb_product'); ?>
            DAFTAR SEKARANG
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('jb_content'); ?>
            Daftarkan identitas anda pada layanan kami 
        <?php $__env->endSlot(); ?>
    <?php if (isset($__componentOriginal58699c985549c3a3935a91454ab93e6eb407ed64)): ?>
<?php $component = $__componentOriginal58699c985549c3a3935a91454ab93e6eb407ed64; ?>
<?php unset($__componentOriginal58699c985549c3a3935a91454ab93e6eb407ed64); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
    <?php $__env->startComponent('daftar.component.form'); ?>
        
    <?php if (isset($__componentOriginalac5ecb1a867c7fa3e1eea0e32b7088813c5df46a)): ?>
<?php $component = $__componentOriginalac5ecb1a867c7fa3e1eea0e32b7088813c5df46a; ?>
<?php unset($__componentOriginalac5ecb1a867c7fa3e1eea0e32b7088813c5df46a); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('daftar.common.daftar_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Rashtaurigae\Desktop\Badu\Web\resources\views/daftar/daftar.blade.php ENDPATH**/ ?>
<section class="people-says-area pt-54 pb-20">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div class="people-asy-title text-center">
                    <h2>WHAT PEOPLE SAYS</h2>
                </div>
                <div class="people-say-slide">
                    <!-- Start single people -->
                    <div class="single-people text-center">
                        <div class="people-say-image">
                            <img src="<?php echo e(asset('/images/voulenteer/roy.jpg')); ?>" alt="">
                        </div>
                        <div class="peoplp-say-text text-center">
                            <p>Lorem ipsum dolor sit amet, con sectetur adipiscing elit. Vestibulum varius semper ligula, et molestie metus.</p>
                            <h5>Zafari Jamith</h5>
                            <h6>Director</h6>
                        </div>
                    </div>
                    <!-- End single people -->
                </div>
            </div>
        </div>
    </div>
</section><?php /**PATH C:\Users\Rashtaurigae\Desktop\Badu\Web\resources\views/content/component/comment.blade.php ENDPATH**/ ?>
<nav class="navbar navbar-light bg-light">
<a class="navbar-brand" href="#">{{$name}}</a>
</nav>
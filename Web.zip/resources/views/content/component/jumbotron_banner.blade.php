<section class="slider-animate-area pb-60">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 text-center">
                <div class="cd-intro">
                    <h1 class="cd-headline clip is-full-width title1 wow zoomIn animated" data-wow-duration="1s" data-wow-delay="300ms" style="visibility: visible; animation-duration: 1s; animation-delay: 300ms; animation-name: zoomIn;">
                        <span>SELAMAT DATANG DI</span>
                        <span class="cd-words-wrapper">
                        <b class="is-visible">{{$jb_product}}</b>
                        </span>
                    </h1>
                    <p class="wow zoomIn animated" data-wow-duration="1s" data-wow-delay="600ms" style="visibility: visible; animation-duration: 1s; animation-delay: 600ms; animation-name: zoomIn;">
                        {{$jb_content}}
                    </p>
                    <div class="slider-button-area wow zoomIn animated" data-wow-duration="1s" data-wow-delay="900ms" style="visibility: visible; animation-duration: 1s; animation-delay: 900ms; animation-name: zoomIn;">
                        <a href="#" class="btn-lg">DOWNLOAD APLIKASI</a>
                        <a href="#" class="btn-lg">PRIVASI & KEBIJAKAN</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
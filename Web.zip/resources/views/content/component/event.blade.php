<section class="countdown-area pt-60 pb-60">
    <div class="container">
        <div class="row">
            <div class="col-sm-5 col-md-4">
                <div class="countdown-side-area">
                    <div class="countdown-icon">
                        <i class="fa fa-calendar-check-o" aria-hidden="true"></i>
                    </div>
                    <div class="countdown-text">
                        <h3>No upcoming event</h3>  
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
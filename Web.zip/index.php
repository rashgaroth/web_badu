<?php

header('public/');
